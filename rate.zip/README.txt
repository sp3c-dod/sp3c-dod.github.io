__//Holy_Flame rate config v 0.2 \\__
Well i had some extra time so made this ^^
u can alter the values in the rate config.

Version 0.2
+Added the rte thing so its easier to edit 


Version v 0.1
+Basic script added
+Including the voice thing

Install
-extract these files to /your@mail.com/day of defeat/dod
-but exec rate.cfg in config or userconfig
-bind +commandmenu to some key
-the default rate switch key is l 
-if you dont want to replace your commandmenu just edit it and add this 
	
	"<Your number here>" "Rate Settings" 
{
		"1" "RATE 1 "	"ratex0"
		"2" "RATE 2 "	"ratex1"
		"3" "RATE 3 "	"ratex2"
	        "4" "RATE 4 "	"ratex3"
		"5" "RATE 5 "	"ratex4"
		"6" "RATE 6 "	"ratex5"
		"7" "RATE 7 "	"ratex6"

}
	
	"0" "Cancel"		"cancel"

Visit #admins.fi @ qnet
www.admins.fi
Visit #sp3c @  gamesurge
www.sp3c.org

-Holy_Flame 
-Hoolyz 